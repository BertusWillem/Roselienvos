<?php
$dbh = new PDO('mysql:host=localhost;dbname=mydb', "root", "root");
//Start een nieuwe SQL connectie
