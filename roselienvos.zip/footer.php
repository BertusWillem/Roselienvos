 <!--footer-->
    <footer>
       &copy; <?php echo date("Y");?>
      <a class="user" href="http://google.nl/">Team Aqua.</a>
      <a>All Rights Reserved.</a>
    </footer>
  </body>
</html>
